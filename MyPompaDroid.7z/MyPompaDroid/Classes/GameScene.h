#ifndef _GAME_SCENE_H_
#define _GAME_SCENE_H_

#include <cocos2d.h>

class GameScene
{
public:

	static cocos2d::Scene* createScene();
};


#endif