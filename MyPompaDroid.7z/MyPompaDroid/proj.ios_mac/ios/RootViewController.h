#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}
- (BOOL) prefersStatusBarHidden;

@end
